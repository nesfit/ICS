﻿namespace LectureSample.BL.Models;

public record UserModel 
{
    public string FirstName { get; set; } = "Karel";
    public string LastName { get; set; } = "Jonasek";

    public string FullName => $"{FirstName} {LastName}";
};