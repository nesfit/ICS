﻿using System.Collections.ObjectModel;
using System.Windows.Input;
using LectureSample.BL.Models;

namespace LectureSample.App.ViewModels;

public class MainViewModel : ViewModelBase
{
    public UserModel Model { get; set; } = new();
    public ObservableCollection<UserModel> Users { get; set; } = new();

    private void Clear()
    {
        Model.FirstName = string.Empty;
        Model.LastName = string.Empty;
    }

    private void Add(UserModel model)
    {
        Users.Add(model);
        Model = new UserModel();
    }
}