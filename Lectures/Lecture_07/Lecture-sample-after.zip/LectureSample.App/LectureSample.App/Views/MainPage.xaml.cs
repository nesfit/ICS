﻿namespace LectureSample.App;

public partial class MainPage : ContentPage
{
    public MainPage()
    {
        InitializeComponent();
    }
}