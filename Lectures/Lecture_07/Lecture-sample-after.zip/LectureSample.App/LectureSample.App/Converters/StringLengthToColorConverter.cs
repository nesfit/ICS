﻿using System.Globalization;

namespace LectureSample.App.Converters;

public class StringLengthToColorConverter : IValueConverter
{
    public object Convert(
        object value,
        Type targetType,
        object parameter,
        CultureInfo culture)
    {
        if (value is string stringValue)
        {
            if (stringValue.Length > 5)
            {
                return Colors.Green;
            }
            else
            {
                return Colors.Yellow;
            }
        }
        return Colors.Chocolate;
    }

    public object ConvertBack(
        object value,
        Type targetType,
        object parameter,
        CultureInfo culture)
    {
        throw new NotImplementedException();
    }
}