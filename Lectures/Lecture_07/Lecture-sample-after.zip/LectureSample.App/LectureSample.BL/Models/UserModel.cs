﻿namespace LectureSample.BL.Models;

public record UserModel : ModelBase
{
    public string FirstName { get; set; } = "Karel";
    public string LastName { get; set; } = "Jonasek";

    public string FullName => $"{FirstName} {LastName}";
};