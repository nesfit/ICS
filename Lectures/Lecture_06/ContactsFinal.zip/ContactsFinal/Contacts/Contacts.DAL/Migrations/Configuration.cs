using Contacts.DAL.Entities;

namespace Contacts.DAL.Migrations
{
    using System.Data.Entity.Migrations;

    internal sealed class Configuration : DbMigrationsConfiguration<Contacts.DAL.ContactsDbContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(Contacts.DAL.ContactsDbContext context)
        {
            context.Contacts.AddOrUpdate(c => c.Id,
                    new ContactEntity { Id = 1, Firstname = "Martin", Lastname = "Dybal", Mail = "martin@dybal.it" },
                    new ContactEntity { Id = 2, Firstname = "Tereza", Lastname = "Hal��ov�" },
                    new ContactEntity { Id = 3, Firstname = "Marie", Lastname = "Markov�" },
                    new ContactEntity { Id = 4, Firstname = "Tom�", Lastname = "Pa�our" },
                    new ContactEntity { Id = 5, Firstname = "Jana", Lastname = "Danielov�" },
                    new ContactEntity { Id = 6, Firstname = "Vlasta", Lastname = "Ot�halov�" },
                    new ContactEntity { Id = 7, Firstname = "Josef", Lastname = "Fran�k" },
                    new ContactEntity { Id = 8, Firstname = "Jakub", Lastname = "Vedl�k" },
                    new ContactEntity { Id = 9, Firstname = "Stanislav", Lastname = "Kopa�ka" },
                    new ContactEntity { Id = 10, Firstname = "Karol�na ", Lastname = "�ern�" },
                    new ContactEntity { Id = 11, Firstname = "Hana", Lastname = "�ern�" },
                    new ContactEntity { Id = 12, Firstname = "Jan", Lastname = "Sychra" },
                    new ContactEntity { Id = 13, Firstname = "Milan", Lastname = "K�pl" }
                );
        }
    }
}