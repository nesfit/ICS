using Contacts.BL;
using Contacts.MVVM.Framework;
using Contacts.ViewModels.Commands;
using Contacts.ViewModels.Messages;
using Contacts.ViewModels.Models;
using Moq;
using Xunit;

namespace Contacts.ViewModels.Tests
{
    public class DeleteContactCommandTests
    {
        [Fact]
        public void DeleteContactComand_CanExecute_IsTrue_Test()
        {
            var deleteContactCommand = CreateDeleteContactCommand();

            var canExecute = deleteContactCommand.CanExecute(null);

            Assert.True(canExecute);
        }

        [Fact]
        public void DeleteContactCommand_Execute_DeleteFromStore_Test()
        {
            var contactsServiceMock = new Mock<IContactsService>();
            var deleteContactCommand = CreateDeleteContactCommand(contactsServiceMock.Object);
            var contact = CreateContactModel();

            deleteContactCommand.Execute(contact);

            contactsServiceMock.Verify(x => x.Delete(It.IsAny<ContactModel>()), Times.Once());
        }

        [Fact]
        public void DeleteContactCommand_Execute_SendsDeletedMessage_Test()
        {
            var messengerMock = new Mock<IMessenger>();
            var deleteContactCommand = CreateDeleteContactCommand(messengerMock.Object);
            var contact = CreateContactModel();

            deleteContactCommand.Execute(contact);

            messengerMock.Verify(x => x.Send(It.IsAny<ContactDeletedMessage>()), Times.Once());
        }

        private static ContactModel CreateContactModel()
        {
            var contact = new ContactModel
            {
                Id = 1,
                Firstname = "Martin",
                Lastname = "Dybal",
                Mail = "martin@dybal.it"
            };
            return contact;
        }

        private DeleteContactCommand CreateDeleteContactCommand(IMessenger messenger)
        {
            return CreateDeleteContactCommand(null, messenger);
        }

        private DeleteContactCommand CreateDeleteContactCommand(IContactsService contactsService = null, IMessenger messenger = null)
        {
            contactsService = contactsService ?? new Mock<IContactsService>().Object;
            messenger = messenger ?? new Mock<IMessenger>().Object;
            return new DeleteContactCommand(contactsService, messenger);
        }
    }
}