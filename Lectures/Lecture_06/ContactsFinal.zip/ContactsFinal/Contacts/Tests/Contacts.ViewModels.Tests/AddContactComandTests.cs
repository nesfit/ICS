using Contacts.BL;
using Contacts.MVVM.Framework;
using Contacts.ViewModels.Commands;
using Contacts.ViewModels.Messages;
using Contacts.ViewModels.Models;
using Moq;
using Xunit;

namespace Contacts.ViewModels.Tests
{
    public class AddContactComandTests
    {
        [Fact]
        public void AddContactComand_CanExecute_IsTrue_Test()
        {
            var saveContactCommandSUT = CreateSaveContactCommandSUT();

            var canExecute = saveContactCommandSUT.CanExecute(null);

            Assert.True(canExecute);
        }

        [Fact]
        public void AddContactComand_Execute_SendsAddedMessage_Test()
        {
            var messengerMock = new Mock<IMessenger>();
            var saveContactCommandSUT = CreateSaveContactCommandSUT(messengerMock.Object);

            saveContactCommandSUT.Execute(null);

            messengerMock.Verify(x => x.Send(It.IsAny<ContactEditedMessage>()), Times.Once());
        }

        [Fact]
        public void AddContactCommand_Execute_SavesToStore_Test()
        {
            var contactsServiceMock = new Mock<IContactsService>();
            var saveContactCommandSUT = CreateSaveContactCommandSUT(contactsServiceMock.Object);

            saveContactCommandSUT.Execute(null);

            contactsServiceMock.Verify(x => x.Save(It.IsAny<ContactModel>()), Times.Once());
        }

        private SaveContactCommand CreateSaveContactCommandSUT(IMessenger messenger)
        {
            return CreateSaveContactCommandSUT(null, messenger);
        }

        private SaveContactCommand CreateSaveContactCommandSUT(IContactsService contactsService = null, IMessenger messenger = null)
        {
            contactsService = contactsService ?? new Mock<IContactsService>().Object;
            messenger = messenger ?? new Mock<IMessenger>().Object;

            return new SaveContactCommand(contactsService, messenger);
        }
    }
}