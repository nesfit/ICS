using System;

namespace Contacts.ViewModels.Properties
{
    [AttributeUsage(AttributeTargets.Property)]
    public sealed class RazorLayoutAttribute : Attribute { }
}