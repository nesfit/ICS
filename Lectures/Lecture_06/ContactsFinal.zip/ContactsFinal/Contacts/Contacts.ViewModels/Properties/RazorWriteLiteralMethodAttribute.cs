using System;

namespace Contacts.ViewModels.Properties
{
    [AttributeUsage(AttributeTargets.Method)]
    public sealed class RazorWriteLiteralMethodAttribute : Attribute { }
}