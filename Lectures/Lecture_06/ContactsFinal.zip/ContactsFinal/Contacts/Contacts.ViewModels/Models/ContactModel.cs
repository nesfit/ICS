﻿namespace Contacts.ViewModels.Models
{
    public class ContactModel
    {
        public string Firstname { get; set; }
        public int Id { get; set; }
        public string Lastname { get; set; }
        public string Mail { get; set; }
        public string PhoneNumber { get; set; }
    }
}