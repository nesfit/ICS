﻿namespace Contacts.ViewModels.UIServices
{
    public enum Window
    {
        ContactList,
        ContactNew,
        ContactEdit
    }
}