﻿using Contacts.BL;
using Contacts.MVVM.Framework;
using Contacts.ViewModels.Commands;
using Contacts.ViewModels.Messages;
using Contacts.ViewModels.Models;
using Contacts.ViewModels.UIServices;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Contacts.ViewModels.ViewModels
{
    public class ContactListViewModel : ViewModelBase
    {
        private readonly IContactsService contactsService;
        private readonly IMessenger messenger;
        private readonly INavigationService navigationService;
        private ObservableCollection<ContactListModel> contacts = new ObservableCollection<ContactListModel>();
        private ContactListModel selectedContact;

        public ICommand DeleteContactCommand { get; }
        public ICommand OpenAddWindowCommand { get; }
        public ICommand OpenEditWindowCommand { get; }

        public ObservableCollection<ContactListModel> Contacts
        {
            get { return contacts; }
            private set
            {
                contacts = value;
                OnPropertyChanged();
            }
        }

        public ContactListModel SelectedContact
        {
            get { return selectedContact; }
            set
            {
                if (Equals(value, selectedContact)) return;
                selectedContact = value;
                OnPropertyChanged();
            }
        }


        public ContactListViewModel(IContactsService contactsService, IMessenger messenger, ICommandFactory commandFactory, INavigationService navigationService, OpenEditWindowCommand openEditWindowCommand, DeleteContactCommand deleteContactCommand)
        {
            this.contactsService = contactsService;
            this.messenger = messenger;
            this.navigationService = navigationService;

            RegisterMessengerMessages();

            DeleteContactCommand = deleteContactCommand;
            OpenAddWindowCommand = commandFactory.CreateCommand(OpenAddWindow);
            OpenEditWindowCommand = commandFactory.CreateCommand(OpenEditWindow, CanOpenEditWindow, this);
        }

        private void RegisterMessengerMessages()
        {
            messenger.Register<ContactAddedMessage>(action: ContactAddedMessageReceived);
            messenger.Register<ContactEditedMessage>(action: ContactEditedMessageReceived);
            messenger.Register<ContactDeletedMessage>(action: ContactDeletedMessageReceived);
        }

        protected override async Task LoadData()
        {
            await base.LoadData();
            await LoadContact();
        }

        private bool CanOpenEditWindow()
        {
            return SelectedContact != null;
        }

        private void ContactAddedMessageReceived(ContactAddedMessage message)
        {
            Contacts.Add(message.Contact.To<ContactListModel>());
        }

        private void ContactDeletedMessageReceived(ContactDeletedMessage message)
        {
            var removedContact = Contacts.SingleOrDefault(c => c.Id == message.Contact.Id);
            Contacts.Remove(removedContact);
        }

        private void ContactEditedMessageReceived(ContactEditedMessage message)
        {
            var editedContact = message.Contact.To<ContactListModel>();
            var editedContactIndex = contacts.IndexOf(contacts.Single(c => c.Id == editedContact.Id));
            var selectedId = SelectedContact?.Id;
            Contacts[editedContactIndex] = editedContact;
            if (selectedId == editedContact.Id)
            {
                SelectedContact = editedContact;
            }
        }

        private async Task LoadContact()
        {
            var contacts = await contactsService.GetContacts<ContactListModel>();
            Contacts = new ObservableCollection<ContactListModel>(contacts);
        }

        private void OpenAddWindow()
        {
            navigationService.OpenWindow(Window.ContactNew);
        }

        private void OpenEditWindow()
        {
            navigationService.OpenWindow(Window.ContactEdit, SelectedContact?.Id);
        }
    }
}