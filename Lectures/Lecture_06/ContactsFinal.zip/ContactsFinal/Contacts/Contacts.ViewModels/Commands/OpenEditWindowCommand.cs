﻿using Contacts.ViewModels.Models;
using Contacts.ViewModels.UIServices;
using System;
using System.Windows.Input;

namespace Contacts.ViewModels.Commands
{
    public class OpenEditWindowCommand : ICommand
    {
        private readonly INavigationService navigationService;

        public event EventHandler CanExecuteChanged;

        public OpenEditWindowCommand(INavigationService navigationService)
        {
            this.navigationService = navigationService;
        }

        public bool CanExecute(object parameter)
        {
            return (parameter as ContactListModel)?.Id != null;
        }

        public void Execute(object parameter)
        {
            var selectedContactId = (parameter as ContactListModel)?.Id;
            if (selectedContactId.HasValue)
            {
                navigationService.OpenWindow(Window.ContactEdit, selectedContactId);
            }
        }
    }
}