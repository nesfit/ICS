﻿namespace Contacts.WPF.Windows
{
    /// <summary>
    /// Interaction logic for ContactNew.xaml
    /// </summary>
    public partial class ContactNew
    {
        public ContactNew()
        {
            InitializeComponent();
        }
    }
}