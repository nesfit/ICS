﻿namespace Contacts.WPF.Windows
{
    /// <summary>
    /// Interaction logic for ContactEdit.xaml
    /// </summary>
    public partial class ContactEdit
    {
        public ContactEdit()
        {
            InitializeComponent();
        }
    }
}