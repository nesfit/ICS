using System;

namespace Contacts.MVVM.Framework.Properties
{
    [AttributeUsage(AttributeTargets.Property)]
    public sealed class AspMethodPropertyAttribute : Attribute { }
}