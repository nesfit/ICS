using System;

namespace Contacts.MVVM.Framework.Properties
{
    [AttributeUsage(AttributeTargets.Method)]
    public sealed class RazorWriteLiteralMethodAttribute : Attribute { }
}