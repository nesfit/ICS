namespace Contacts.BL
{
    public static class MapperHelpers
    {
        public static TDestination To<TDestination>(this object source)
        {
            return AutoMapper.Mapper.Map<TDestination>(source);
        }
    }
}