﻿using System.Threading.Tasks;
using Microsoft.Extensions.Caching.Memory;

namespace Decorator.Inheritance
{
    class CachedRepository : LoggedRepository
    {
        private readonly IMemoryCache memoryCache;

        public CachedRepository(IMemoryCache memoryCache)
        {
            this.memoryCache = memoryCache;
        }

        public override async Task<string> GetById(int id)
        {
            if (!memoryCache.TryGetValue<string>(id, out string result))
            {
                result = await base.GetById(id);
                memoryCache.Set(id, result);
            }

            return result;
        }
    }
}