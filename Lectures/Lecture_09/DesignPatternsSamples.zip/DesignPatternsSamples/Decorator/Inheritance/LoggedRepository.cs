﻿using System;
using System.Threading.Tasks;

namespace Decorator.Inheritance
{
    class LoggedRepository : Repository
    {
        public override async Task<string> GetById(int id)
        {
            var methodName = nameof(GetById);
            ConsoleLogMessage(ConsoleColor.Yellow, $"Method: {methodName} start");
            try
            {
                var result = await base.GetById(id);
                ConsoleLogMessage(ConsoleColor.Yellow, $"Method: {methodName} was succeed");
                return result;
            }
            catch (Exception e)
            {
                ConsoleLogMessage(ConsoleColor.Red, $"Exception {e} was raised in Method: {methodName}");
                throw;
            }
            finally
            {
                ConsoleLogMessage(ConsoleColor.Yellow, $"Method: {methodName} exit");
            }
        }

        private void ConsoleLogMessage(ConsoleColor color, string message, params object[] args)
        {
            var originalColor = Console.ForegroundColor;
            Console.ForegroundColor = color;
            Console.WriteLine(message, args);
            Console.ForegroundColor = originalColor;
        }
    }
}