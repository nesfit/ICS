﻿using System.Threading.Tasks;

namespace Decorator
{
    public interface IRepository
    {
        Task<string> GetById(int id);
    }
}