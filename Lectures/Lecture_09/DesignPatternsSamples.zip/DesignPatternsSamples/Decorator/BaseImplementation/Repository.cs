﻿using System;
using System.Threading.Tasks;

namespace Decorator
{
    class Repository : IRepository
    {
        public virtual async Task<string> GetById(int id)
        {
            await Task.Delay(TimeSpan.FromSeconds(5));
            return $"item with {id}";
        }
    }
}