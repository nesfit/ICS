﻿using System;
using System.Threading.Tasks;

namespace Decorator
{
    class App
    {
        private readonly IRepository repository;

        public App(IRepository repository)
        {
            this.repository = repository;
        }

        public async Task Run(App app)
        {
            var id = 42;

            await app.PrintItem(id);
            await app.PrintItem(id);
        }

        private async Task PrintItem(int id)
        {
            var item = await repository.GetById(id);
            Console.WriteLine(item);
        }
    }
}