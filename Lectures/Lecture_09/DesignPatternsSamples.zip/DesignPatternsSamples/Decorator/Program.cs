﻿using System.Threading.Tasks;
using Decorator.Decorators;
using Microsoft.Extensions.Caching.Memory;

namespace Decorator
{
    class Program
    {
        static Task Main(string[] args)
        {
            var memoryCache = new MemoryCache(new MemoryCacheOptions());

            var app = new App(new LoggedRepository(new CachedRepository(new Repository(), memoryCache)));
            //var app = new App(new Inheritance.CachedRepository(memoryCache));

            return app.Run(app);
        }
    }
}
