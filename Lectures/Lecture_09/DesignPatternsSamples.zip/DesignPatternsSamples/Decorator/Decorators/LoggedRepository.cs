﻿using System;
using System.Threading.Tasks;

namespace Decorator.Decorators
{
    class LoggedRepository : IRepository
    {
        private readonly IRepository repository;

        public LoggedRepository(IRepository repository)
        {
            this.repository = repository;
        }

        public async Task<string> GetById(int id)
        {
            var methodName = nameof(GetById);
            ConsoleLogMessage(ConsoleColor.Yellow, $"Method: {methodName} start");
            try
            {
                var result = await repository.GetById(id);
                ConsoleLogMessage(ConsoleColor.Yellow, $"Method: {methodName} was succeed");
                return result;
            }
            catch (Exception e)
            {
                ConsoleLogMessage(ConsoleColor.Red, $"Exception {e} was raised in Method: {methodName}");
                throw;
            }
            finally
            {
                ConsoleLogMessage(ConsoleColor.Yellow, $"Method: {methodName} exit");
            }
        }

        private void ConsoleLogMessage(ConsoleColor color, string message, params object[] args)
        {
            var originalColor = Console.ForegroundColor;
            Console.ForegroundColor = color;
            Console.WriteLine(message, args);
            Console.ForegroundColor = originalColor;
        }
    }
}