﻿using System.Threading.Tasks;
using Microsoft.Extensions.Caching.Memory;

namespace Decorator.Decorators
{
    class CachedRepository : IRepository
    {
        private readonly IMemoryCache memoryCache;

        private readonly IRepository repository;
        
        public CachedRepository(IRepository repository, IMemoryCache memoryCache)
        {
            this.repository = repository;
            this.memoryCache = memoryCache;
        }

        public async Task<string> GetById(int id)
        {
            if (!memoryCache.TryGetValue<string>(id, out string result))
            {
                result = await repository.GetById(id);
                memoryCache.Set(id, result);
            }

            return result;
        }
    }
}