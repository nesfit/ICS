﻿using UserManagement.ConsoleApp.Composite;
using UserManagement.ConsoleApp.Emails;

namespace UserManagement.ConsoleApp.Visitor.Advanced
{
    public class SendMailUserVisitor : UserVisitorBase
    {

        private readonly IMailerService mailerService;
        private Email email;

        public SendMailUserVisitor(IMailerService mailerService)
        {
            this.mailerService = mailerService;
        }

        public void SendEmail(IUserComponent userComponent, Email email)
        {
            this.email = email;
            base.Visit(userComponent);
        }

        protected override void Visit(NullIUserComponent userComponent)
        {
            
        }

        protected override void Visit(UserComponent userComponent)
        {
            mailerService.SendEmail(userComponent.Email, email);
        }

        protected override void Visit(UserGroupComposite userGroupComposite)
        {
            foreach (var member in userGroupComposite.Members)
            {
                SendEmail(member, email);
            }
        }
    }
}