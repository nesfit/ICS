﻿using System;
using UserManagement.ConsoleApp.Composite;

namespace UserManagement.ConsoleApp.Visitor.Advanced
{
    public abstract class UserVisitorBase
    {
        protected virtual void Visit(IUserComponent userComponent)
        {
            switch (userComponent)
            {
                case UserComponent component:
                    Visit(component);
                    break;

                case UserGroupComposite composite:
                    Visit(composite);
                    break;

                case NullIUserComponent nullIUserComponent:
                    Visit(nullIUserComponent);
                    break;

                default:
                    throw new NotSupportedException();
            }
        }
        protected abstract void Visit(NullIUserComponent userComponent);
        protected abstract void Visit(UserComponent userComponent);
        protected abstract void Visit(UserGroupComposite userGroupComposite);
    }
}