﻿using System;
using UserManagement.ConsoleApp.Composite;

namespace UserManagement.ConsoleApp.Visitor.Advanced
{
    public class DisplayUserVisitor : UserVisitorBase
    {
        private int indent;
        public void Print(IUserComponent userComponent)
        {
            indent = 0;
            base.Visit(userComponent);
        }

        protected override void Visit(NullIUserComponent userComponent)
        {
            PrintIndentedText($"User not found");
        }   

        protected override void Visit(UserComponent userComponent)
        {
            PrintIndentedText($"User: {userComponent.Name}");
        }

        protected override void Visit(UserGroupComposite userGroupComposite)
        {
            PrintIndentedText($"Group: {userGroupComposite.Name}");
            indent++;
            foreach (var member in userGroupComposite.Members)
            {
                Visit(member);
            }
            indent--;
        }

        private void PrintIndentedText(string text)
        {
            var indentTabs = new string('\t', indent);
            Console.WriteLine(indentTabs + text);
        }
    }

}