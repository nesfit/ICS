﻿using UserManagement.ConsoleApp.Composite;
using UserManagement.ConsoleApp.Emails;
using UserManagement.ConsoleApp.Visitor.Advanced;

namespace UserManagement.ConsoleApp.Facade
{
    public class UserFacade
    {
        private readonly DisplayUserVisitor displayUserVisitor;
        private readonly SendMailUserVisitor sendMailUserVisitor;

        public UserFacade(DisplayUserVisitor displayUserVisitor, SendMailUserVisitor sendMailUserVisitor)
        {
            this.displayUserVisitor = displayUserVisitor;
            this.sendMailUserVisitor = sendMailUserVisitor;
        }

        public void IncreaseSalary(IUserComponent userComponent, int percent)
        {
            userComponent.IncreaseSalary(percent);
        }

        public void Print(IUserComponent userComponent)
        {
            displayUserVisitor.Print(userComponent);
        }

        public void SendEmail(IUserComponent userComponent, Email email)
        {
            sendMailUserVisitor.SendEmail(userComponent, email);
        }
    }
}