﻿namespace UserManagement.ConsoleApp.Composite
{
    public interface IUserComponent
    {
        string Name { get; }
        void IncreaseSalary(int percent);
    }
}