﻿namespace UserManagement.ConsoleApp.Composite
{
    public class NullIUserComponent : IUserComponent
    {
        public string Name { get; } = string.Empty;

        public void IncreaseSalary(int percent)
        {
            // I'm nobody so I don't have to increase my salary
        }
    }
}