﻿using System;
using UserManagement.ConsoleApp.Emails;
using UserManagement.ConsoleApp.Facade;
using UserManagement.ConsoleApp.Singleton;

namespace UserManagement.ConsoleApp
{
    class UserManagementApp
    {
        private readonly NewsletterFactory newsletterFactory;
        private readonly IEmployeeStorage employeeStorage;
        private readonly UserFacade userFacade;

        public UserManagementApp(NewsletterFactory newsletterFactory, IEmployeeStorage employeeStorage, UserFacade userFacade)
        {
            this.newsletterFactory = newsletterFactory;
            this.employeeStorage = employeeStorage;
            this.userFacade = userFacade;
        }


        public void Start()
        {
            userFacade.Print(employeeStorage.Employees);

            Console.WriteLine(new string('-', 100));

            var newsletter = newsletterFactory.CreateNewsletter();
            userFacade.SendEmail(employeeStorage.Developers, newsletter);
        }
    }
}
