﻿using UserManagement.ConsoleApp.Composite;

namespace UserManagement.ConsoleApp.Singleton
{
    public interface IEmployeeStorage
    {
        IUserComponent Developers { get; }
        IUserComponent Employees { get; }
        IUserComponent Designers { get; }
        IUserComponent PythonTeam { get; }
        IUserComponent DotNetTeam { get; }
    }
}