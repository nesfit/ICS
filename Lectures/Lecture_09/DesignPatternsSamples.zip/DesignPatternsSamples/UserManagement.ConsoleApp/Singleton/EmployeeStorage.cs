﻿using UserManagement.ConsoleApp.Composite;

namespace UserManagement.ConsoleApp.Singleton
{
    public sealed class EmployeeStorage : IEmployeeStorage
    {
        public IUserComponent Developers { get; }
        public IUserComponent Employees { get; }
        public IUserComponent Designers { get; }
        public IUserComponent PythonTeam { get; }
        public IUserComponent DotNetTeam { get; }

        public static IEmployeeStorage Instance { get; } = new EmployeeStorage();

        private EmployeeStorage()
        {
            var roman = new UserComponent { Firstname = "Roman", Email = "roman@super-company.com" };
            var tibor = new UserComponent { Firstname = "Tibor", Email = "tibor@super-company.com" };
            var martin = new UserComponent { Firstname = "Martin", Email = "martin@super-company.com" };
            var adam = new UserComponent { Firstname = "Adam", Email = "adam@super-company.com" };
            var joe = new UserComponent { Firstname = "Joe", Email = "joe@super-company.com" };
            var jake = new UserComponent { Firstname = "Jake", Email = "jake@super-company.com" };
            var emily = new UserComponent { Firstname = "Emily", Email = "emily@super-company.com" };
            var sophia = new UserComponent { Firstname = "Sophia", Email = "sophia@super-company.com" };
            var brian = new UserComponent { Firstname = "Brian", Email = "brian@super-company.com" };
            var bob = new UserComponent { Firstname = "Bob", Email = "bob@super-company.com" };

            DotNetTeam = new UserGroupComposite
            {
                Name = ".NET team",
                Members = { roman, tibor, martin, adam }
            };

            PythonTeam = new UserGroupComposite
            {
                Name = "Python team",
                Members = { emily, sophia, brian, bob }
            };

            Designers = new UserGroupComposite
            {
                Name = "Design team",
                Members = { joe, jake }
            };

            Developers = new UserGroupComposite
            {
                Name = "Developers",
                Members = { DotNetTeam, PythonTeam }
            };

            Employees = new UserGroupComposite
            {
                Name = "Employees",
                Members = { Developers, Designers }
            };
        }
    }
}
