﻿#nullable enable
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace NullObject
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            var searchService = new SearchService();
            foreach (var person in searchService.SearchByName("M"))
            {
                Console.WriteLine(person.Name);
            }

            string? s = null;

        }
    }

    public class SearchService
    {
        public IEnumerable<IPerson> SearchByName(string name)
        {
            return GetAllPersons().Where(person => person.Name.StartsWith(name));
        }

        private IPerson[] GetAllPersons()
        {
            return new IPerson[]
            {
                new Person("John"),
                new Person("Martin"),
                new Person("Joe"),
                new NullPerson(),
                null,
                new Person("Bob")
            };
        }
    }

    public interface IPerson
    {
        string Name { get; }
    }

    class Person : IPerson
    {
        public string Name { get; }

        public Person(string name)
        {
            Name = name;
        }
    }

    class NullPerson : IPerson
    {
        public string Name { get; } = string.Empty;
    }
}
