﻿using System;
using Visitor.Composite;
using Visitor.Visitor;

namespace Visitor
{
    class Program
    {
        static void Main(string[] args)
        {

            var roman = new UserComponent { Firstname = "Roman", Email = "roman@super-company.com" };
            var tibor = new UserComponent { Firstname = "Tibor", Email = "tibor@super-company.com" };
            var martin = new UserComponent { Firstname = "Martin", Email = "martin@super-company.com" };
            var adam = new UserComponent { Firstname = "Adam", Email = "adam@super-company.com" };

            var dotnetTeam = new UserGroupComposite
            {
                Name = ".NET team",
                Members = { roman, tibor, martin, adam }
            };

            var displayUserVisitor = new DisplayUserVisitor();
            displayUserVisitor.Print(dotnetTeam);
        }
    }
}
