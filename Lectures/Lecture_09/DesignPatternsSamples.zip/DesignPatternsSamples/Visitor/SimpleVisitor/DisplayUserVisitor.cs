﻿using System;
using Visitor.Composite;

namespace Visitor.SimpleVisitor
{
    public class DisplayUserVisitor
    {
        public void Print(IUserComponent userComponent)
        {
            Print(userComponent, 0);
        }

        private void Print(IUserComponent userComponent, int indent)
        {
            if (userComponent is UserComponent user)
            {
                Print(user, indent);
            }
            else if (userComponent is UserGroupComposite group)
            {
                Print(group, indent);
            }
            else
            {
                throw new NotSupportedException();
            }
        }

        private void Print(UserComponent userComponent, int indent)
        {
            PrintIndentedText($"User: {userComponent.Name}", indent);
        }

        private void Print(UserGroupComposite userGroupComposite, int indent)
        {
            PrintIndentedText($"Group: {userGroupComposite.Name}", indent);
            indent++;
            foreach (var member in userGroupComposite.Members)
            {
                Print(member, indent);
            }
        }

        private void PrintIndentedText(string text, int indent)
        {
            var indentTabs = new string('\t', indent);
            Console.WriteLine(indentTabs + text);
        }
    }
}