﻿using System;
using Visitor.Composite;

namespace Visitor.Visitor
{
    public abstract class UserVisitorBase
    {
        protected virtual void Visit(IUserComponent userComponent)
        {
            switch (userComponent)
            {
                case UserComponent component:
                    Visit(component);
                    break;
                case UserGroupComposite composite:
                    Visit(composite);
                    break;
                default:
                    throw new NotSupportedException();
            }
        }
        protected abstract void Visit(UserComponent userComponent);
        protected abstract void Visit(UserGroupComposite userGroupComposite);
    }
}